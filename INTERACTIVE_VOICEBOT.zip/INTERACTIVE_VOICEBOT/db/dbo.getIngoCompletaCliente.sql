-------------------------------------
---- getInfoCompletaCliente_v1 ----
-------------------------------------
USE [PRE_TV]
GO

/****** Object:  StoredProcedure [dbo].[getInfoCompletaCliente_v1] ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [dbo].[getInfoCompletaCliente_v1] 
	
	-- Variable de entrada: telefono
	@PRM_IN_telefono varchar(15) 

AS
DECLARE    
	
	-- Variables auxiliares
	@numInstalaciones int,
	@telefono varchar(500),
	@dni varchar(500),
	@nombre varchar(500),
	@tipo_cliente varchar(500),
	@idioma varchar(500),
	@listaInstalaciones varchar (500)
	@PRM_IN_ins_no varchar(500)

BEGIN   
	BEGIN TRY

		SET @numInstalaciones = 0;
		
		-- Condición si se interoduce un telefono
		IF (LEN(@PRM_IN_telefono)=9)  

			-- Sentencia para obtener el numero y el listado de instalaciones en funcion del telefono 
			-- de entrada del procedimiento separados por '#'.
			SELECT @numInstalaciones = @numInstalaciones + 1, @telefono=c.telefono, @dni=c.dni, 
			@nombre=c.nombre, @tipo_cliente=c.tipo_cliente, @idioma=c.idioma,
			@listaInstalaciones = COALESCE(@listaInstalaciones + '#','') + c.ins_no
			FROM contacto c
			WHERE c.phone = @PRM_IN_telefono 
			GROUP BY c.ins_no;
		
		-- Condicion si se introduce una instalacion
		ELSE  
		
			-- Sentencia para obtener el numero y el listado de instalaciones en funcion de la instalacion 
			-- de entrada del procedimiento separados por '#'.
			@PRM_IN_ins_no=@PRM_IN_telefono;	
			SELECT @numInstalaciones = @numInstalaciones + 1, @telefono=c.telefono, @dni=c.dni, 
			@nombre=c.nombre, @tipo_cliente=c.tipo_cliente, @idioma=c.idioma,
			@listaInstalaciones = COALESCE(@listaInstalaciones + '#','') + c.ins_no
			FROM contacto c
			WHERE c.ins_no = @PRM_IN_ins_no 
			GROUP BY c.ins_no;

		-- Comprobacion del numero de instalaciones
		IF @numInstalaciones = 0
		BEGIN
			SET @listaInstalaciones = '-'; 
			SET @telefono = '-'; 
			SET @dni = '-'; 
			SET @nombre = '-'; 
			SET @tipo_cliente = '-'; 
			SET @idioma = '-';
			GOTO Salida;
		END
		GOTO Salida;

	END TRY
	-- Captura de excepción
	BEGIN CATCH
		SET @listaInstalaciones = '-';
		SET @telefono = '-'; 
		SET @dni = '-'; 
		SET @nombre = '-'; 
		SET @tipo_cliente = '-'; 
		SET @idioma = '-';		
		GOTO Salida;  
	END CATCH     

	Salida: 
		SELECT CONVERT(VARCHAR(5),@numInstalaciones) + '#' + @listaInstalaciones + '#' + @telefono + '#'+ 
		@dni + '#'+ @nombre + '#'+ @tipo_cliente + '#'+ @idioma + '#' AS PRM_OUT_listaInstalaciones;
		RETURN 0;	            
END
GO