// FUNCION EMPLEADA EN LA RUTINA MAIN
// Parámetros de entrada: recibe el valor introducido por el usuario en el sistema, el cual debe ser un numero
// de instalación o u número de teléfono
// Parámetros de salida: devuelve un string reconociendo cual de los dos tipos ha introducido el usuario
function identificar_ani_ins (identificar){
	var tipo = '';
	
	if(identificar.length == 7){
		tipo = 'instalacion';
	}
	else if (identificar.length == 9){
		tipo = 'telefono';
	}
	
	else {
		tipo = 'no identificado';
	}
	
	return tipo;
	
}

// FUNCION EMPLEADA EN LA RUTINA MAIN
// Parámetros de entrada: ninguno. Se recoge el valor devuelvo por un procedimiento almacenado
// Parámetros de salida: cantidad de instalaciones asociadas a un cliente 
function cantidadInstalaciones (){
	var ins_lista = String(AppState.PROC_obtenerInstalaciones_VRU_ANIDBResult);
	var arraySplit = ins_lista.split("#");
	var cantidadInst = arraySplit[0];
	
	return cantidadInst;
	
}

// FUNCION EMPLEADA EN LA RUTINA MAIN
// Parámetros de entrada: una variable auxiliar que se autoincrementa para ir recogiendo uno a uno los números de cada instalación asociada
// Parámetros de salida: el número de la instalación en la posición buscada
function numInstalacion (posicion){
	var ins_lista = String(AppState.PROC_obtenerInstalaciones_VRU_ANIDBResult);
	var arraySplit = ins_lista.split("#");
	
	return arraySplit[posicion];
	
}

// FUNCION EMPLEADA EN SUBRUTINA EVALUAR SALTO DE ALARMA
// Parámetros de entrada: cantidad de instalaciones y todas las características de las instalaciones concatenadas por '#' 
// Parámetros de salida: la instalación que se encuentra en estado de salto
function evaluarSaltoAlarma (caractInstalaciones, cantidadInstalaciones){

	var separador1 = '#';
	var separador2 = '|';
	var arrayTotalCaracteristicas=caractInstalaciones.split(separador1)
	var numeroInstalacion = '';
    var arrayCaract = '';
	var estadoInstalacion = '';
	var numeroInstalacion_EnSalto = '';
	var i = 0;
    
    for (i; i<cantidadInstalaciones; i++){

   		arrayCaract=arrayTotalCaracteristicas[i].split(separador2); 
    	numeroInstalacion=arrayCaract[0];
    	estadoInstalacion=arrayCaract[3];	
        	if (estadoInstalacion=='Salto'){
            	numeroInstalacion_EnSalto=numeroInstalacion;
            	break;	
			}
    }
	return numeroInstalacion_EnSalto;

}

// FUNCION EMPLEADA EN LA SUBRUTINA EVALUAR TIPO DE CLIENTE
// Parámetros de entrada: toda la información del cliente concatenada por '#' (ejemplo:'cantidad_instalaciones#numero_instalacion#phone#dni#nombre#tipo_cliente#idioma')
// Parámetros de salida: se devuelve el idioma, el tipo de cliente y el nombre del cliente se asignan a las variables declaradas
// en Composer directamente
function datosCliente (infoCliente){

	var posicion_tipoCliente = 5;
	var posicion_nombreCliente = 4;
	var posicion_idiomaCliente = 6;
    var separador = '#';
	var arrayInfoCliente = infoCliente.split(separador);
	var cantidadTotalInsta = parseInt(arrayInfoCliente[0]);
	var posicionFinal_tipoCliente = posicion_tipoCliente + (cantidadTotalInsta-1);
    var posicionFinal_nombreCliente = posicion_nombreCliente + (cantidadTotalInsta-1);
    var posicionFinal_idiomaCliente = posicion_idiomaCliente + (cantidadTotalInsta-1);

    Appstate.PRM_OUT_TipoCliente = arrayInfoCliente[posicionFinal_tipoCliente];
    Appstate.PRM_OUT_NombreClienteVip = arrayInfoCliente[posicionFinal_nombreCliente];
	
    return arrayInfoCliente[posicionFinal_idiomaCliente];

}

// FUNCION EMPLEADA EN LA RUTINA MAIN
// Parámetros de entrada: valor devuelvo por el procedimineto alamacenado que devuelve las características de una instalación a partir de un número de instalación
// Parámetros de salida: la concatenación de todas las carcaterísticas conjuntas de todas las instalaciones que tiene un cliente, separadas por '#'
function leerCaractInst (getCaract){
	
	return AppState.caractLeidas = AppState.caractLeidas + getCaract +"#"; 
	
}

// FUNCION EMPLEADA EN TODAS LAS SUBRUTINAS Y EN LA RUTINA MAIN
// Parámetros de entrada: el tipo de formato con el que se quiere calcular una fecha (son 3 formatos para 3 cometidos distintos)
// Parámetros de salida: devuelve el cálculo de la fecha en el formato seleccionado
function calculoFechas (formato){
	
	var today = new Date();
	var dia = String(today.getDate()); 
	var mes = String(today.getMonth() + 1); //January is 0!
	var anio = String(today.getFullYear());
	var hora = String(today.getHours());
	var minuto = String(today.getMinutes());
	var segundo = String(today.getSeconds());
	
	//FECHA DE LA VENTANA DEL LOG --> FORMATO = yyyyMMddhhmmss
	if (formato == 'fechaLog'){
		
		//CASO ESPECIAL PARA HORAS CON UN DIGITO (que aparezca un '0')
		if(hora < 10){
			hora = "0" + hora;
		}
		if(minuto < 10){
			minuto = "0" + minuto;
		}
		if(segundo < 10){
			segundo = "0" + segundo;
		}
		
		//PERSONALIZAR LA HORA DE SALIDA	
		return today = anio+mes+dia+hora+minuto+segundo;
	}
	
	// FECHA DE CADA TRAZA QUE SE INTRODUCE AL ENTRAR EN EL BACKEND --> FORMATO = dd/MM/yyyy hh:mm:ss
	if (formato == 'fechaTraza'){
		
		//CASO ESPECIAL PARA HORAS CON UN DIGITO (que aparezca un '0')
		if(hora < 10){
			hora = "0" + hora;
		}
		if(minuto < 10){
			minuto = "0" + minuto;
		}
		if(segundo < 10){
			segundo = "0" + segundo;
		}
		
		//PERSONALIZAR LA HORA DE SALIDA	
		return today = dia + '/' + mes + '/' + anio + ' ' + hora + ':' + minuto + ':' + segundo;
	}
	
	//FECHA ACTUAL PARA CALCULAR LA DURACION DE LA IVR --> FORMATO = tipo Date()
	if ( formato == 'fechaParaDuracion'){
		return today;
	}
	
}

// FUNCION EMPLEADA EN LA RUTINA MAIN
// Parámetros de entrada: se introducen dos variables, por un lado la fecha calculada al inicio de la interacción voicebot, 
// y por el otro la fecha calculada a la salida de dicha interaccion
// Parámetros de salida: se devuelve la diferencia de ambas fechas, siendo esto la duración de la llamada
function duracionLlamada (fechaEntradaCompleta, fechaSalidaCompleta) {
	
	var horaEntrada;
	var horaSalida;
	var diferencia = 0;
	var duracion = 0;
	
	//FECHAS EN MS CON TIMESTAMP	
	horaEntrada = fechaEntradaCompleta.getTime();
	horaSalida = fechaSalidaCompleta.getTime();
	
	//CALCULO DE LA DIFERENCIA
	diferencia = horaSalida - horaEntrada;
	
	//CALCULO DURACION EN SEGUNDOS
	duracion = diferencia/1000;
	return duracion + ' seg';
	
}


// FUNCION EMPLEADA EN LA SUBRUTINA FUNCIONES VOICEBOT
// Parámetros de entrada: el número de la instalación sobre la que se quiere realizar una acción 
// (en caso de tener una instalación, dicho parámetro estará vacío) cuantas instalaciones hay y 
// todas las carcaterísticas de estas instalaciones separadas por '#'
// Parámetros de salida: el estado de la alarma (Desarmada, Alarmada, Salto o Inactiva)
function estadoAlarma (caractInstalaciones, cantidadInstalaciones, numInstalacionAccion){

	var separador1 = '#';
	var separador2 = '|';
	var arrayTotalCaracteristicas=caractInstalaciones.split(separador1)
	var numeroInstalacion = '';
    var arrayCaract = '';
	var estadoInstalacion = '';
	var i = 0;
	
	if(cantiladInstalaciones==1){
		arrayCaract=arrayTotalCaracteristicas[0].split(separador2); 
		estadoInstalacion=arrayCaract[3];           		
	}else {
    
		for (i; i<cantidadInstalaciones; i++){

			arrayCaract=arrayTotalCaracteristicas[i].split(separador2); 
			numeroInstalacion=arrayCaract[0];
				if (numeroInstalacion == numInstalacionAccion){
					estadoInstalacion=arrayCaract[3];	
					break;
				}
		}
    
	}
	return estadoInstalacion;
}

// FUNCION EMPLEADA EN LA SUBRUTINA FUNCIONES VOICEBOT
// Parámetros de entrada: las características conjuntas de todas las intalaciones, la cantidad de instalaciones asociadas,
// el número de instalación sobre el que realizar una acción (en caso de tener una instalación, dicho parámetro estará vacío) 
// y el código de seguridad introducido por el usuario
// Parámetros de salida: devuelve 'true' si el código introducido es correcto o 'false' en caso contrario
function evaluarCodigoAlarma (caractInstalaciones, cantidadInstalaciones, numInstalacionAccion, codigoIntroducido){

	var separador1 = '#';
	var separador2 = '|';
	var arrayTotalCaracteristicas=caractInstalaciones.split(separador1)
	var numeroInstalacion = '';
    var arrayCaract = '';
	var codigoInstalacion = '';
	var numeroInstalacion_EnSalto = '';
	var i = 0;
    var codigoCorrecto = 'false';
    
    if(cantiladInstalaciones==1){
		arrayCaract=arrayTotalCaracteristicas[0].split(separador2); 
		codigoInstalacion=arrayCaract[7];
		if(codigoInstalacion == codigoIntroducido){
        	codigoCorrecto = 'true';        	
        }
		
	}else {
    
	    for (i; i<cantidadInstalaciones; i++){
	
	   		arrayCaract=arrayTotalCaracteristicas[i].split(separador2); 
	    	numeroInstalacion=arrayCaract[0];
	        if (numeroInstalacion == numInstalacionAccion){
	        	codigoInstalacion=arrayCaract[7];	
	            if(codigoInstalacion == codigoIntroducido){
	            	codigoCorrecto = 'true';
	            	break;
	            }
	        }
	    }
	}
    return codigoCorrecto;

}


function instMasReciente (caractLeidas, cantidadInst){
	
	var arraySplit1 = caractLeidas.split('#');
	var mesNum = 0;
	var dateTimeInst = '';
	var dateTime = '';
	var numInst = '';
	var arraySplit2 = '';
	var fechaInstCompleta = '';
	var fechaSplit = '';
	var mes = '';
	var dia = '';
	var anio = '';
	var horaCompleta1 = '';
	var horaCompleta = '';
	var horaSplit = '';
	var hora = '';
	var horaSplit = '';
	var hora = '';
	var segSplit = '';
	var seg1 = '';
	var seg = '';
	var seg2 = '';
	var date;
	var i = 0;
	var j = 0;
	
	//COMPLETAMOS Y ACONDICIONAMOS LA FECHA
	for (i=0; i<cantidadInst; i++){
		arraySplit2= arraySplit1[i].split('|');
	 	fechaInstCompleta = arraySplit2[26];
	    
	    numInst = arraySplit2[0];
	    fechaSplit = fechaInstCompleta.split(' ');
	    
	    mes = fechaSplit[0];
	    dia = fechaSplit[1];
	    anio = fechaSplit[2];
	    horaCompleta1 = fechaSplit[3];
	    horaCompleta = fechaSplit[4];
	    
	    //COMPROBACION DE SI LA HORA TIENE 1 O 2 DIGITOS (numero de espacios)
	    if (horaCompleta1 != ''){
	    	horaSplit = horaCompleta1.split(':');
	        hora = horaSplit[0];
	    }
	    else {
	    	horaSplit = horaCompleta.split(':');
	        hora = horaSplit[0];
		} 
	    
	    segSplit = horaSplit[1];
	    //COMPROBACION DE SI LA HORA ES 'AM' O 'PM'
	    if (segSplit.indexOf('AM') != -1) {
	    	seg1 = segSplit.split('AM');
	    	seg = seg1[0];
	    }
	    else {
	    	seg2 = segSplit.split('PM');
	        seg = seg2[0];
	    }
	    
	    //TRANSFORMACION DEL MES A UN NUMERO
	    switch (mes) {
        case 'Jan':
        	mesNum = 0;
            break;
    	case 'Feb':
        	mesNum = 1;
            break;
        case 'Mar':
        	mesNum = 2;
            break;
        case 'Apr':
        	mesNum = 3;
            break;
        case 'May':
        	mesNum = 4;
            break;
        case 'Jun':
        	mesNum = 5;
            break;
        case 'Jul':
        	mesNum = 6;
            break;
        case 'Aug':
        	mesNum = 7;
            break;
        case 'Sep':
        	mesNum = 8;
            break;
        case 'Oct':
        	mesNum = 9;
            break;
        case 'Nov':
        	mesNum = 10;
            break;
        case 'Dec':
        	mesNum = 11;
            break;
	    }
	    //RELLENAMOS FECHA ACONDICIONADA Y HACEMOS CAST A MILISEGUNDOS
	    date = new Date (anio, mesNum, dia, hora, seg);
	    dateTimeInst = dateTimeInst + date.getTime() +':'+ numInst +', '; //Variable con la fecha (en ms) y la instalacion asociada
	    dateTime = dateTime + date.getTime() + ', '; //Variable con solo la fecha (en ms)
	}
	
	//CÁLCULO DE LA FECHA (en ms) MAS RECIENTE (maximo)
	var arrayDateTime = dateTime.split(',');
	var fechaMasReciente = Math.max.apply(null, arrayDateTime);
	
	//BUSCAMOS LA INSTALACION MAS RECIENTE ASOCIADA A LA FECHA A PARTIR DE POSICIONES EN LA CADENA
	var posFecha = dateTimeInst.indexOf(fechaMasReciente);
	var posInst = posFecha + 14;
	var instReciente = '';
	for (j=0; j<5; j++){
		instReciente = instReciente + dateTimeInst.charAt(posInst + j);
	}
	return instReciente;
}

function idiomaInstMasReciente(getCaractReciente){
	
	var getCaract = String(getCaractReciente);
	var arraySplit = getCaract.split('|');
	var idioma = arraySplit[3];
	return idioma;
	
}

function caractInstalacionVip (caractLeidas, cantidadInst){
	
	var arraySplit1 = caractLeidas.split('#');
	var vip = "";
	var i = 0;
	var arraySplit2;
	var caractInstVip = '';
	
	for (i=0; i<cantidadInst; i++) {
	 	arraySplit2 = arraySplit1[i].split('|');
	    vip = arraySplit2[10];

	    if (vip =='QA'){
	        caractInstVip = caractInstVip + arraySplit1[i] + '#';
	    }
	}
	return caractInstVip;
}

function comprobarVip (caractInstVip){
	
	var esVip;
	if (caractInstVip == '') {
		 	esVip = false;
	}
	else {
		 	esVip = true;
	}
	return esVip;
}

function cantidadInstalacionesVip (caractInstVip){
	
	var cantInstVip = 0;
	var arraySplit = caractInstVip.split('#');
	
	while (arraySplit[cantInstVip] != '') {
		cantInstVip = cantInstVip + 1;
	}
	return cantInstVip;
}


function idioma (idioma) {
	
	var idiomaLocucion = '';
	
	if (idioma == 'ING') {
		idiomaLocucion = 'Ingles';
	}
	else if (idioma == 'ESP') {		
		idiomaLocucion = 'Espaniol';
	}	
	else {
		idiomaLocucion = 'Indefinido';
	}
	
	return idiomaLocucion;
}